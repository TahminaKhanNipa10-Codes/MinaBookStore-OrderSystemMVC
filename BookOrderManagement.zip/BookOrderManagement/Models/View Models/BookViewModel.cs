﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BookOrderManagement.Models.View_Models
{
    public class BookViewModel
    {
        public int BookId { get; set; }

        [Required(ErrorMessage = "Book Name is required")]
        [Display(Name = "Book Name")]
        [StringLength(200)]
        public string BookTitle { get; set; }

        [Required(ErrorMessage = "Author Name is required")]
        [Display(Name = "Author Name")]
        [StringLength(200)]
        public string AuthorName { get; set; }

        [Required(ErrorMessage = "Unit is required")]
        [Display(Name = "Unit")]
        [StringLength(50)]
        public string Unit { get; set; }

        [Required(ErrorMessage = "Unit Price is required")]
        [Display(Name = "Unit Price")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Unit Price must be greater than 0")]
        public decimal UnitPrice { get; set; }

        [Required(ErrorMessage = "Available Quantity is required")]
        [Display(Name = "Available Quantity")]
        [Range(0, int.MaxValue, ErrorMessage = "Available Quantity cannot be negative")]
        public int AvailableQuantity { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; }

        [Display(Name = "Upload Image")]
        public HttpPostedFileBase ImageFile { get; set; }
        public string BookCoverImage { get; set; }

        [Required(ErrorMessage = "Product Category is required")]
        [Display(Name = "Product Category")]
        public int? CategoryId { get; set; }

        [Display(Name = "Category Name")]
        public string  CategoryName { get; set; }
    }
}