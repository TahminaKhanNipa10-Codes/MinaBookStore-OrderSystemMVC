﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BookOrderManagement.Models.View_Models
{
    public class BookCategoryViewModel
    {

        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Category Name is required")]
        [Display(Name = "Category Name")]
        [StringLength(100)]
        public string CategoryName { get; set; }

        [Display(Name = "Category Description")]
        [StringLength(500)]
        [DataType(DataType.MultilineText)]
        public string CategoryDescription { get; set; }
    }
}