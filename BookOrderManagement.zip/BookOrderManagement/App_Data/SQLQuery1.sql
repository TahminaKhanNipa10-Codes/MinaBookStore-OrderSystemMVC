USE master
GO

CREATE  DATABASE BookStoreDB1
GO

USE BookStoreDB1
GO

-- 1. Category Table
CREATE TABLE BookCategory (
    CategoryId INT PRIMARY KEY IDENTITY(1,1),
    CategoryName NVARCHAR(100) NOT NULL,
    CategoryDescription NVARCHAR(500) NULL
)
GO

-- 2. Book Table (Replacing Product)
CREATE TABLE Book (
    BookId INT PRIMARY KEY IDENTITY(1,1),
    BookTitle NVARCHAR(200) NOT NULL,
    AuthorName NVARCHAR(200) NOT NULL,
    Unit NVARCHAR(50) NOT NULL DEFAULT 'Pcs',
    UnitPrice DECIMAL(18,2) NOT NULL,
    AvailableQuantity INT NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    BookCoverImage NVARCHAR(500) NULL,
    CategoryId INT FOREIGN KEY REFERENCES BookCategory(CategoryId)
)
GO

-- 3. Customer Table
CREATE TABLE Customer (
    CustomerId INT PRIMARY KEY IDENTITY(1,1),
    CustomerName NVARCHAR(200) NOT NULL,
    ContactNumber NVARCHAR(20) NOT NULL,
    ContactAddress NVARCHAR(500) NOT NULL
)
GO

-- 4. Orders Table
CREATE TABLE Orders (
    OrderId INT PRIMARY KEY IDENTITY(1,1),
    CustomerId INT FOREIGN KEY REFERENCES Customer(CustomerId),
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    TotalAmount DECIMAL(18,2) NOT NULL
)
GO

-- 5. Order Details Table
CREATE TABLE OrderDetails (
    OrderDetailsId INT PRIMARY KEY IDENTITY(1,1),
    OrderId INT FOREIGN KEY REFERENCES Orders(OrderId) ON DELETE CASCADE,
    CategoryId INT FOREIGN KEY REFERENCES BookCategory(CategoryId),
    BookId INT FOREIGN KEY REFERENCES Book(BookId),
    OrderUnit NVARCHAR(50) NOT NULL,
    OrderQuantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    Amount DECIMAL(18,2) NOT NULL
)
GO

-- =============================================
-- Insert Sample Data
-- =============================================

-- Categories
INSERT INTO BookCategory (CategoryName, CategoryDescription) VALUES 
('Literature', 'Classic and modern literature'),
('Science Fiction', 'Sci-fi novels and space adventures'),
('Programming', 'Technical books on software development'),
('History', 'Historical facts and biographies'),
('Children', 'Story books for kids')
GO

-- Books (Replacing Products)
INSERT INTO Book (BookTitle, AuthorName, UnitPrice, AvailableQuantity, CategoryId) VALUES 
('Pather Panchali', 'Bibhutibhushan Bandyopadhyay', 350.00, 50, 1),
('Shesher Kobita', 'Rabindranath Tagore', 250.00, 40, 1),
('The Martian', 'Andy Weir', 550.00, 30, 2),
('Learn SQL', 'John Smith', 450.00, 100, 3),
('Clean Code', 'Robert C. Martin', 1200.00, 25, 3),
('History of Bengal', 'Dr. Abdul Karim', 600.00, 15, 4),
('Thakurmar Jhuli', 'Dakshinaranjan Mitra Majumder', 180.00, 80, 5)
GO

-- Customers
INSERT INTO Customer (CustomerName, ContactNumber, ContactAddress) VALUES 
('Karim Ahmed', '01711111111', 'Dhaka, Bangladesh'),
('Fatima Rahman', '01722222222', 'Chittagong, Bangladesh')
GO

-- Orders & Details
DECLARE @CID INT = (SELECT TOP 1 CustomerId FROM Customer)
INSERT INTO Orders (CustomerId, OrderDate, TotalAmount) VALUES (@CID, GETDATE(), 1550.00)
DECLARE @OID INT = SCOPE_IDENTITY()

INSERT INTO OrderDetails (OrderId, CategoryId, BookId, OrderQuantity,OrderUnit, UnitPrice, Amount) VALUES
(@OID, 3, 5, 1,'pcs', 1200.00, 1200.00),
(@OID, 1, 1, 1,'pcs', 350.00, 350.00)
GO

-- Select Data
SELECT * FROM BookCategory
SELECT * FROM Book
SELECT * FROM Customer
SELECT * FROM Orders
SELECT * FROM OrderDetails