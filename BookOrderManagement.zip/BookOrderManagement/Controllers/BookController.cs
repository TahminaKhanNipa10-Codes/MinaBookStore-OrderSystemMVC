﻿using BookOrderManagement.Models;
using BookOrderManagement.Models.View_Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace BookOrderManagement.Controllers
{
    public class BookController : Controller
    {
        private BookStoreDBEntities db = new BookStoreDBEntities();

        // GET: Book
        public ActionResult Index(int? categoryId, string searchName)
        {
            var books = db.Books.Include(b => b.BookCategory).AsQueryable();
            // Filter by Category
            if (categoryId.HasValue && categoryId.Value > 0)
            {
                books = books.Where(b => b.CategoryId == categoryId.Value);
            }

            // Filter by Product Name
            if (!string.IsNullOrEmpty(searchName))
            {
                books = books.Where(b => b.BookTitle.Contains(searchName));
            }
            var bookList = books.Select(b => new BookViewModel
            {
                BookId = b.BookId,
                BookTitle = b.BookTitle,
                AuthorName = b.AuthorName,
                Unit = b.Unit,
                UnitPrice = b.UnitPrice,
                AvailableQuantity = b.AvailableQuantity,
                BookCoverImage = b.BookCoverImage,
                CategoryId = b.CategoryId,
                CategoryName = b.BookCategory.CategoryName,
                IsActive = b.IsActive
            }).ToList();
            // Send categories to view
            ViewBag.Categories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            ViewBag.SelectedCategory = categoryId;
            ViewBag.SearchName = searchName;
            return View(bookList);
        }

        // GET: Book/Create
        public ActionResult Create()
        {
            
            ViewBag.CategoryId = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(BookViewModel model)
        {
            if (ModelState.IsValid)
            {
                var book = new Book
                {
                    BookTitle = model.BookTitle,
                    AuthorName = model.AuthorName,
                    Unit = model.Unit,
                    UnitPrice = model.UnitPrice,
                    AvailableQuantity = model.AvailableQuantity,
                    IsActive = model.IsActive,
                    CategoryId = model.CategoryId
                };
                // Handle image upload
                if (model.ImageFile != null && model.ImageFile.ContentLength > 0)
                {
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.ImageFile.FileName);
                    string path = Path.Combine(Server.MapPath("~/Images"), fileName);
                    model.ImageFile.SaveAs(path);
                    book.BookCoverImage = fileName;
                }
                db.Books.Add(book);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book created successfully!";
                return RedirectToAction("Index");
            }
            ViewBag.CategoryId = new SelectList(db.BookCategories, "CategoryId", "CategoryName", model.CategoryId);
            return View(model);
        }
        // GET: Product/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            var model = new BookViewModel
            {
                BookId = book.BookId,
                BookTitle = book.BookTitle,
                AuthorName = book.AuthorName,
                Unit = book.Unit,
                UnitPrice = book.UnitPrice,
                AvailableQuantity = book.AvailableQuantity,
                BookCoverImage = book.BookCoverImage,
                CategoryId = book.CategoryId,
                IsActive = book.IsActive
            };
            ViewBag.CategoryId = new SelectList(db.BookCategories, "CategoryId", "CategoryName", model.CategoryId);
            return View(model);
        }

        // POST: Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(BookViewModel model)
        {
            if (ModelState.IsValid)
            {
                var book = db.Books.Find(model.BookId);
                if (book == null)
                {
                    return HttpNotFound();
                }
                book.BookTitle = model.BookTitle;
                book.AuthorName = model.AuthorName;
                book.Unit = model.Unit;
                book.UnitPrice = model.UnitPrice;
                book.AvailableQuantity = model.AvailableQuantity;
                book.CategoryId = model.CategoryId.Value;
                book.IsActive = model.IsActive;

                // Handle image upload
                if (model.ImageFile != null && model.ImageFile.ContentLength > 0)
                {
                    // Delete old image if exists
                    if (!string.IsNullOrEmpty(book.BookCoverImage))
                    {
                        string oldImagePath = Path.Combine(Server.MapPath("~/Images"), book.BookCoverImage);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }
                    // Save new image
                    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.ImageFile.FileName);
                    string path = Path.Combine(Server.MapPath("~/Images"), fileName);
                    model.ImageFile.SaveAs(path);
                    book.BookCoverImage = fileName;
                }
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book updated successfully!";
                return RedirectToAction("Index");
            }
            ViewBag.CategoryId = new SelectList(db.BookCategories, "CategoryId", "CategoryName", model.CategoryId);
            return View(model);
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var book = db.Books.Include(p => p.BookCategory).FirstOrDefault(p => p.BookId == id);
            if (book == null)
            {
                return HttpNotFound();
            }
            var model = new BookViewModel
            {
                BookId = book.BookId,
                BookTitle = book.BookTitle,
                AuthorName = book.AuthorName,
                Unit = book.Unit,
                UnitPrice = book.UnitPrice,
                AvailableQuantity = book.AvailableQuantity,
                BookCoverImage = book.BookCoverImage,
                CategoryId = book.CategoryId,
                CategoryName = book.BookCategory.CategoryName
            };
            return View(model);
        }

        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                var book = db.Books.Find(id);
                if (book == null)
                {
                    return HttpNotFound();
                }
                // Delete image if exists
                if (!string.IsNullOrEmpty(book.BookCoverImage))
                {
                    string imagePath = Path.Combine(Server.MapPath("~/Images"), book.BookCoverImage);
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }
                db.Books.Remove(book);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book deleted successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["ErrorMessage"] = "Cannot delete this Book. It may have related orders.";
                return RedirectToAction("Index");
            }
        }

        // AJAX: Get Products by Category
        [HttpGet]
        public JsonResult GetProductsByCategory(int categoryId)
        {
            var books = db.Books
                .Where(p => p.CategoryId == categoryId && p.IsActive)
                .Select(p => new
                {
                    BookId = p.BookId,
                    BookTitle = p.BookTitle,
                    AuthorName = p.AuthorName,
                    Unit = p.Unit,
                    UnitPrice = p.UnitPrice,
                    AvailableQuantity = p.AvailableQuantity
                }).ToList();
            return Json(books, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        [HttpPost]
        public JsonResult ToggleStatus(int id)
        {
            try
            {
                var book = db.Books.Find(id);
                if (book == null)
                {
                    return Json(new { success = false, message = "Book not found" });
                }

                book.IsActive = !book.IsActive;
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();

                return Json(new { success = true, isActive = book.IsActive });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

    }
}