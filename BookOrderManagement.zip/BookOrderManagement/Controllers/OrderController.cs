﻿using BookOrderManagement.Models;
using BookOrderManagement.Models.View_Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Transactions;
using System.Web;
using System.Web.Mvc;

namespace BookOrderManagement.Controllers
{
    public class OrderController : Controller
    {
        private BookStoreDBEntities db =new BookStoreDBEntities();
        // GET: Order
        public ActionResult Index()
        {
            var orders = db.Orders.Include(o => o.Customer)
                .OrderByDescending(o => o.OrderDate)
                .Select(o => new OrderMasterViewModel
                {
                    OrderId = o.OrderId,
                    CustomerName = o.Customer.CustomerName,
                    ContactNumber = o.Customer.ContactNumber,
                    ContactAddress = o.Customer.ContactAddress,
                    OrderDate = o.OrderDate,
                    TotalAmount = o.TotalAmount,
                    CustomerId = o.CustomerId
                }).ToList();

            return View(orders);
        }

        // GET: Order/Create
        public ActionResult Create()
        {
            ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            return View(new OrderMasterViewModel());
        }

        // POST: Order/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(OrderMasterViewModel model, string OrderDetailsListJson)
        {
            // Deserialize JSON order details
            if (!string.IsNullOrEmpty(OrderDetailsListJson))
            {
                model.OrderDetailsList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<OrderDetailsViewModel>>(OrderDetailsListJson);
            }

            if (ModelState.IsValid)
            {
                if (model.OrderDetailsList == null || !model.OrderDetailsList.Any())
                {
                    TempData["ErrorMessage"] = "Please add at least one book to the order.";
                    ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                    return View(model);
                }

                using (var transaction = new TransactionScope())
                {
                    try
                    {
                        // Validate stock availability and product status
                        foreach (var item in model.OrderDetailsList)
                        {
                            var book = db.Books.Find(item.BookId);
                            
                            // Check if book exists
                            if (book == null)
                            {
                                TempData["ErrorMessage"] = "One or more products in your order no longer exist.";
                                ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                                return View(model);
                            }
                            
                            // Check if product is inactive
                            if (!book.IsActive)
                            {
                                TempData["ErrorMessage"] = $"Cannot order {book.BookTitle}. This product is currently inactive.";
                                ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                                return View(model);
                            }
                            
                            if (book.AvailableQuantity < item.OrderQuantity)
                            {
                                TempData["ErrorMessage"] = $"Insufficient stock for {book.BookTitle}. Available: {book.AvailableQuantity}";
                                ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                                return View(model);
                            }
                        }

                        // Create or find customer
                        var customer = db.Customers.FirstOrDefault(c => c.ContactNumber == model.ContactNumber);
                        if (customer == null)
                        {
                            customer = new Customer
                            {
                                CustomerName = model.CustomerName,
                                ContactNumber = model.ContactNumber,
                                ContactAddress = model.ContactAddress
                            };
                            db.Customers.Add(customer);
                            db.SaveChanges();
                        }
                        else
                        {
                            // Update customer info
                            customer.CustomerName = model.CustomerName;
                            customer.ContactAddress = model.ContactAddress;
                            db.Entry(customer).State = EntityState.Modified;
                            db.SaveChanges();
                        }

                        // Create order
                        var order = new Order
                        {
                            CustomerId = customer.CustomerId,
                            OrderDate = DateTime.Now,
                            TotalAmount = model.OrderDetailsList.Sum(d => d.Amount)
                        };
                        db.Orders.Add(order);
                        db.SaveChanges();

                        // Create order details and update product quantity
                        foreach (var item in model.OrderDetailsList)
                        {
                            var orderDetail = new OrderDetail
                            {
                                OrderId = order.OrderId,
                                CategoryId = item.CategoryId,
                                BookId = item.BookId,
                                OrderQuantity = item.OrderQuantity,
                                OrderUnit = item.OrderUnit,
                                UnitPrice = item.UnitPrice,
                                Amount = item.Amount
                            };
                            db.OrderDetails.Add(orderDetail);

                            // Update product quantity
                            var product = db.Books.Find(item.BookId);
                            product.AvailableQuantity -= item.OrderQuantity;
                            db.Entry(product).State = EntityState.Modified;
                        }

                        db.SaveChanges();
                        transaction.Complete();

                        TempData["SuccessMessage"] = "Order placed successfully!";
                        return RedirectToAction("Index");
                    }
                    catch (Exception ex)
                    {
                        TempData["ErrorMessage"] = "Error placing order: " + ex.Message;
                        ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                        return View(model);
                    }
                }
            }

            ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            return View(model);
        }

        // GET: Order/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var order = db.Orders.Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                .FirstOrDefault(o => o.OrderId == id);

            if (order == null)
            {
                return HttpNotFound();
            }

            var model = new OrderMasterViewModel
            {
                OrderId = order.OrderId,
                CustomerName = order.Customer.CustomerName,
                ContactNumber = order.Customer.ContactNumber,
                ContactAddress = order.Customer.ContactAddress,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                OrderDetailsList = order.OrderDetails.Select(od => new OrderDetailsViewModel
                {
                    OrderDetailsId = od.OrderDetailsId,
                    BookTitle = od.Book.BookTitle,
                    CategoryName = od.BookCategory.CategoryName,
                    OrderQuantity = od.OrderQuantity,
                    OrderUnit = od.OrderUnit,
                    UnitPrice = od.UnitPrice,
                    Amount = od.Amount
                }).ToList()
            };

            return View(model);
        }

        // GET: Order/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var order = db.Orders.Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                .FirstOrDefault(o => o.OrderId == id);

            if (order == null)
            {
                return HttpNotFound();
            }

            var model = new OrderMasterViewModel
            {
                OrderId = order.OrderId,
                CustomerId = order.CustomerId,
                CustomerName = order.Customer.CustomerName,
                ContactNumber = order.Customer.ContactNumber,
                ContactAddress = order.Customer.ContactAddress,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                OrderDetailsList = order.OrderDetails.Select(od => new OrderDetailsViewModel
                {
                    OrderDetailsId = od.OrderDetailsId,
                    OrderId = od.OrderId,
                    CategoryId = od.CategoryId,
                    BookId = od.BookId,
                    OrderQuantity = od.OrderQuantity,
                    OrderUnit = od.OrderUnit,
                    UnitPrice = od.UnitPrice,
                    Amount = od.Amount,
                    BookTitle = od.Book.BookTitle,
                    CategoryName = od.BookCategory.CategoryName
                }).ToList()
            };

            ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            return View(model);
        }

        // POST: Order/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(OrderMasterViewModel model, string OrderDetailsListJson)
        {
            // Deserialize JSON order details
            if (!string.IsNullOrEmpty(OrderDetailsListJson))
            {
                model.OrderDetailsList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<OrderDetailsViewModel>>(OrderDetailsListJson);
            }

            if (ModelState.IsValid)
            {
                if (model.OrderDetailsList == null || !model.OrderDetailsList.Any())
                {
                    TempData["ErrorMessage"] = "Please add at least one product to the order.";
                    ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                    return View(model);
                }

                using (var transaction = new TransactionScope())
                {
                    try
                    {
                        var order = db.Orders.Include(o => o.OrderDetails).FirstOrDefault(o => o.OrderId == model.OrderId);
                        if (order == null)
                        {
                            return HttpNotFound();
                        }

                        // Restore original product quantities
                        foreach (var oldDetail in order.OrderDetails.ToList())
                        {
                            var book = db.Books.Find(oldDetail.BookId);
                            book.AvailableQuantity += oldDetail.OrderQuantity;
                            db.Entry(book).State = EntityState.Modified;
                        }

                        // Validate stock availability for new quantities
                        foreach (var item in model.OrderDetailsList)
                        {
                            var book = db.Books.Find(item.BookId);
                            if (book.AvailableQuantity < item.OrderQuantity)
                            {
                                // Restore quantities before returning error
                                foreach (var oldDetail in order.OrderDetails)
                                {
                                    var prod = db.Books.Find(oldDetail.BookId);
                                    prod.AvailableQuantity -= oldDetail.OrderQuantity;
                                    db.Entry(prod).State = EntityState.Modified;
                                }
                                db.SaveChanges();

                                TempData["ErrorMessage"] = $"Insufficient stock for {book.BookTitle}. Available: {book.AvailableQuantity}";
                                ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                                return View(model);
                            }
                        }

                        // Update customer
                        var customer = db.Customers.Find(order.CustomerId);
                        customer.CustomerName = model.CustomerName;
                        customer.ContactNumber = model.ContactNumber;
                        customer.ContactAddress = model.ContactAddress;
                        db.Entry(customer).State = EntityState.Modified;

                        // Delete old order details
                        db.OrderDetails.RemoveRange(order.OrderDetails);

                        // Create new order details and update product quantities
                        foreach (var item in model.OrderDetailsList)
                        {
                            var orderDetail = new OrderDetail
                            {
                                OrderId = order.OrderId,
                                CategoryId = item.CategoryId,
                                BookId = item.BookId,
                                OrderQuantity = item.OrderQuantity,
                                OrderUnit = item.OrderUnit,
                                UnitPrice = item.UnitPrice,
                                Amount = item.Amount
                            };
                            db.OrderDetails.Add(orderDetail);

                            // Update product quantity
                            var book = db.Books.Find(item.BookId);
                            book.AvailableQuantity -= item.OrderQuantity;
                            db.Entry(book).State = EntityState.Modified;
                        }

                        // Update order
                        order.TotalAmount = model.OrderDetailsList.Sum(d => d.Amount);
                        db.Entry(order).State = EntityState.Modified;

                        db.SaveChanges();
                        transaction.Complete();

                        TempData["SuccessMessage"] = "Order updated successfully!";
                        return RedirectToAction("Index");
                    }
                    catch (Exception ex)
                    {
                        TempData["ErrorMessage"] = "Error updating order: " + ex.Message;
                        ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
                        return View(model);
                    }
                }
            }

            ViewBag.BookCategories = new SelectList(db.BookCategories, "CategoryId", "CategoryName");
            return View(model);
        }

        // GET: Order/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var order = db.Orders.Include(o => o.Customer)
                .Include(o => o.OrderDetails)
                .FirstOrDefault(o => o.OrderId == id);

            if (order == null)
            {
                return HttpNotFound();
            }

            var model = new OrderMasterViewModel
            {
                OrderId = order.OrderId,
                CustomerName = order.Customer.CustomerName,
                ContactNumber = order.Customer.ContactNumber,
                ContactAddress = order.Customer.ContactAddress,
                OrderDate = order.OrderDate,
                TotalAmount = order.TotalAmount,
                OrderDetailsList = order.OrderDetails.Select(od => new OrderDetailsViewModel
                {
                    BookTitle = od.Book.BookTitle,
                    CategoryName = od.BookCategory.CategoryName,
                    OrderQuantity = od.OrderQuantity,
                    OrderUnit = od.OrderUnit,
                    UnitPrice = od.UnitPrice,
                    Amount = od.Amount
                }).ToList()
            };

            return View(model);
        }

        // POST: Order/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            using (var transaction = new TransactionScope())
            {
                try
                {
                    var order = db.Orders.Include(o => o.OrderDetails).FirstOrDefault(o => o.OrderId == id);
                    if (order == null)
                    {
                        return HttpNotFound();
                    }

                    // Restore product quantities
                    foreach (var detail in order.OrderDetails)
                    {
                        var product = db.Books.Find(detail.BookId);
                        product.AvailableQuantity += detail.OrderQuantity;
                        db.Entry(product).State = EntityState.Modified;
                    }

                    db.Orders.Remove(order);
                    db.SaveChanges();
                    transaction.Complete();

                    TempData["SuccessMessage"] = "Order deleted successfully!";
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Error deleting order: " + ex.Message;
                    return RedirectToAction("Index");
                }
            }
        }

        // AJAX: Get Product Details
        [HttpGet]
        public JsonResult GetProductDetails(int bookId)
        {
            var book = db.Books.Find(bookId);
            if (book == null || !book.IsActive)
            {
                return Json(new { success = false, message = "Product is not available for ordering." }, JsonRequestBehavior.AllowGet);
            }

            return Json(new
            {
                success = true,
                unit = book.Unit,
                unitPrice = book.UnitPrice,
                availableQuantity = book.AvailableQuantity
            }, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}