﻿using BookOrderManagement.Models;
using BookOrderManagement.Models.View_Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.Mvc;

namespace BookOrderManagement.Controllers
{
    public class BookCategoryController : Controller
    {
        private BookStoreDBEntities db = new BookStoreDBEntities();
        // GET: BookCategory
        public ActionResult Index()
        {
            var categories = db.BookCategories.Select(c => new BookCategoryViewModel
            {
                CategoryId = c.CategoryId,
                CategoryName = c.CategoryName,
                CategoryDescription = c.CategoryDescription
            }).ToList();

            return View(categories);
        }
        // GET: ProductCategory/Create
        public ActionResult Create()
        {
            return View();

        }

        // POST: ProductCategory/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(BookCategoryViewModel model)
        {
            if (ModelState.IsValid)
            {
                var category = new BookCategory
                {
                    CategoryName = model.CategoryName,
                    CategoryDescription = model.CategoryDescription
                };
                db.BookCategories.Add(category);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book Category created successfully!";
                return RedirectToAction("Index");
            }
            return View(model);
        }

        // GET: ProductCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var category = db.BookCategories.Find(id);
            if (category == null)
            {
                return HttpNotFound();
            }
            var model = new BookCategoryViewModel
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                CategoryDescription = category.CategoryDescription
            };
            return View(model);
        }
        // POST: ProductCategory/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(BookCategoryViewModel model)
        {
            if (ModelState.IsValid)
            {
                var category = db.BookCategories.Find(model.CategoryId);
                if (category == null)
                {
                    return HttpNotFound();
                }
                category.CategoryName = model.CategoryName;
                category.CategoryDescription = model.CategoryDescription;
                db.Entry(category).State = EntityState.Modified;
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book Category updated successfully!";
                return RedirectToAction("Index");
            }
            return View(model);
        }
        // GET: ProductCategory/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var category = db.BookCategories.Find(id);
            if (category == null)
            {
                return HttpNotFound();
            }
            var model = new BookCategoryViewModel
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                CategoryDescription = category.CategoryDescription
            };
            return View(model);
        }
        // POST: ProductCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                var category = db.BookCategories.Find(id);
                if (category == null)
                {
                    return HttpNotFound();
                }
                db.BookCategories.Remove(category);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Book Category deleted successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception)
{
                TempData["ErrorMessage"] = "Cannot delete this category. It may have related Books.";
                return RedirectToAction("Index");
            }
            }
protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var category = db.BookCategories.Find(id);
            if (category == null)
            {
                return HttpNotFound();
            }
            var model = new BookCategoryViewModel
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                CategoryDescription = category.CategoryDescription
            };
            return View(model);
        }


    }
}